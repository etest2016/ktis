TestHelpers.commonWidgetTests( "progressbar", {
	defaults: {
		disabled: false,
		max: 100,
		value: 0,

		//callbacks
		change: null,
		complete: null,
		create: null
	}
});
